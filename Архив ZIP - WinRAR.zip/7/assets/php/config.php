<?php
	//Встановлюємо дані для роботи сайту
	$config = '{
		"database": {
			"host": "localhost",
			"user": "root",
			"password": "",
			"database": "db"			
		}
	}';
?>