<!DOCTYPE html>
<html>
<head>
	<title>4</title>
	<meta charset="utf-8">
</head>
<body>
	<ul>
		<li><a href="assets/php/hrefRead.php?url=in.html">Знаходження посилань</a></li>
		<li><a href="assets/php/readPhones.php">Номера телефонів</a></li>
		<li><a href="assets/php/readDates.php?file=dates.txt">Входження дати та її заміна</a></li>
		<li><a href="assets/php/dateSearch.php?file=comment.txt">Входження дат в коментарі</a></li>
		<li><a href="assets/php/combinations.php?file=combinations.txt">Входження слів</a></li>
		<li><a href="assets/php/nameValid.php">Валідація імені та прізвища</a></li>
	</ul>
</body>
</html>