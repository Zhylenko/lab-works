<!DOCTYPE html>
<html>
<head>
	<title>1</title>
	<meta charset="utf-8">
</head>
<body>
	<a href="show.php">Вивести дані</a>

	<form action="assets/php/save.php" method="post">
		<input type="text" name="task">
		<input type="date" name="date">
		<input type="submit">
	</form>
</body>
</html>